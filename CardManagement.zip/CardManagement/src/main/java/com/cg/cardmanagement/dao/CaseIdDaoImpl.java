package com.cg.cardmanagement.dao;

import java.math.BigInteger;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.RollbackException;
import javax.persistence.TypedQuery;

import org.hibernate.mapping.Collection;
import org.springframework.stereotype.Repository;

import com.cg.cardmanagement.exception.ErrorMessages;
import com.cg.cardmanagement.exception.IBSException;
import com.cg.cardmanagement.model.CaseIdBean;

@Repository
public class CaseIdDaoImpl implements CaseIdDao {
	// private static Logger logger = Logger.getLogger(CaseIdDaoImpl.class);
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public boolean verifyQueryId(String queryId) throws IBSException {
		boolean result = false;

		try {
			CaseIdBean d = entityManager.find(CaseIdBean.class, queryId);
			if (d != null)
				result = true;
		} catch (NoResultException e) {
			throw new IBSException("gf");
		}
		return result;
	}

	@Override
	public List<CaseIdBean> viewAllServiceRequests() throws IBSException {
		List<CaseIdBean> caseBeans = null;
		try {
			TypedQuery<CaseIdBean> creditQuery = entityManager.createQuery(SqlQueries.SELECT_DATA_FROM_SERVICE_REQUESTS,
					CaseIdBean.class);
			caseBeans = creditQuery.getResultList();
		} catch (NoResultException e) {

			throw new IBSException(ErrorMessages.SER_REQ_NOT_EXIST_MESSAGE);
		}
		return caseBeans;

	}

	@Override
	public void setQueryStatus(String queryId, String newStatus, String remarks, LocalDateTime timestamp)
			throws IBSException {
		// logger.info("entered into setQueryStatus method of CaseIdDaoImpl class");
		try {
			CaseIdBean query = entityManager.find(CaseIdBean.class, queryId);
			if (query != null) {
				query.setStatusOfServiceRequest(newStatus);
				query.setBankAdminRemarks(remarks);
				query.setBankTimeStamp(timestamp);
				entityManager.merge(query);

			}
		} catch (RollbackException e) {
			throw new IBSException("No such request");
		}

	}

	@Override
	public String getNewType(String queryId) throws IBSException {
		// logger.info("entered into getNewType method of CaseIdDaoImpl class");

		CaseIdBean caseId = entityManager.find(CaseIdBean.class, queryId);
		return caseId.getDefineServiceRequest();
	}

	@Override
	public void actionServiceRequest(CaseIdBean caseIdObj) throws IBSException {
		// logger.info("entered into actionServiceRequest method of CaseIdDaoImpl
		// class");
		try {
System.out.println("t");
System.out.println(caseIdObj);
			entityManager.persist(caseIdObj);

		} catch (RollbackException e) {
			System.out.println("e");
			throw new IBSException(ErrorMessages.INTERNAL_ERROR);

		}

	}

	@Override
	public String getCustomerReferenceStatus(CaseIdBean caseIdObj, String customerReferenceId) throws IBSException {
		// logger.info("entered into getCustomerReferenceStatus method of CaseIdDaoImpl
		// class");
		String status;
		try {
			TypedQuery<String> query = entityManager.createQuery(
					"Select d.statusOfServiceRequest from CaseIdBean d where customerReferenceId=:customerRef",
					String.class);
			query.setParameter("customerRef", customerReferenceId);
			status = query.getSingleResult();
		} catch (NoResultException e) {
			throw new IBSException(ErrorMessages.NO_CUSTREFERENCESTATUS);
		}
		return status;

	}

	@Override
	public BigInteger getNewUCI(String queryId) throws IBSException {
		// logger.info("entered into getNewUCI method of CaseIdDaoImpl class");
		BigInteger UCI = null;
		try {
			TypedQuery<BigInteger> query = entityManager.createQuery(
					"select a.UCI from CaseIdBean d INNER JOIN d.customerBeanObject a where d.caseIdTotal=:queryID",
					BigInteger.class);
			query.setParameter("queryID", queryId);

			UCI = query.getSingleResult();
		} catch (NoResultException e) {
			throw new IBSException(ErrorMessages.NO_UCI);
		}
		return UCI;
	}

	@Override
	public CaseIdBean getCaseObj(String queryId) throws IBSException {
		// logger.info("entered into getCaseObj method of CaseIdDaoImpl class");
		CaseIdBean obj = null;
		try {
			obj = entityManager.find(CaseIdBean.class, queryId);
			System.out.println(obj);
		} catch (NullPointerException e) {
			throw new IBSException(ErrorMessages.NO_QUERIES);
		}
		return obj;
	}

	@Override
	public List<CaseIdBean> viewCreditMismatchQueries(Integer bankerId) throws IBSException {
		List<CaseIdBean> listOfQueries;
		try {
			TypedQuery<CaseIdBean> query = entityManager
					.createQuery(SqlQueries.SELECT_DATA_FROM_SERVICE_REQUEST_FOR_CREDIT_MISMATCH, CaseIdBean.class);
			query.setParameter("bankerId", bankerId);
			
			listOfQueries = query.getResultList();
			System.out.println("cdxc");
			System.out.println(listOfQueries);
		} catch (NoResultException e) {
			throw new IBSException(ErrorMessages.NO_QUERIES);
		}
		return listOfQueries;
	}

	@Override
	public List<CaseIdBean> viewDebitMismatchQueries(Integer bankerId) throws IBSException {
		List<CaseIdBean> listOfQueries = null;
		try {
			TypedQuery<CaseIdBean> query = entityManager
					.createQuery(SqlQueries.SELECT_DATA_FROM_SERVICE_REQUEST_FOR_DEBIT_MISMATCH, CaseIdBean.class);
			query.setParameter("bankerId", bankerId);
			listOfQueries = query.getResultList();
		} catch (NoResultException e) {
			throw new IBSException(ErrorMessages.NO_QUERIES);
		}
		return listOfQueries;
	}

	@Override
	public List<CaseIdBean> viewCreditUpgradeQueries(Integer bankerId) throws IBSException {
		List<CaseIdBean> listOfQueries = null;
		try {
			TypedQuery<CaseIdBean> query = entityManager
					.createQuery(SqlQueries.SELECT_DATA_FROM_SERVICE_REQUEST_FOR_CREDIT_UPGRADE, CaseIdBean.class);
			query.setParameter("bankerId", bankerId);
			listOfQueries = query.getResultList();
		} catch (NoResultException e) {
			throw new IBSException(ErrorMessages.NO_QUERIES);
		}
		return listOfQueries;
	}

	@Override
	public List<CaseIdBean> viewDebitUpgradeQueries(Integer bankerId) throws IBSException {
		List<CaseIdBean> listOfQueries = null;
		try {
			TypedQuery<CaseIdBean> query = entityManager
					.createQuery(SqlQueries.SELECT_DATA_FROM_SERVICE_REQUEST_FOR_DEBIT_UPGRADE, CaseIdBean.class);
			query.setParameter("bankerId", bankerId);
			listOfQueries = query.getResultList();
		} catch (NoResultException e) {
			throw new IBSException(ErrorMessages.NO_QUERIES);
		}
		return listOfQueries;
	}

	@Override
	public List<CaseIdBean> viewNewCreditQueries(Integer bankerId) throws IBSException {
		List<CaseIdBean> listOfQueries = null;
		try {
			TypedQuery<CaseIdBean> query = entityManager
					.createQuery(SqlQueries.SELECT_DATA_FROM_SERVICE_REQUEST_FOR_NEW_CREDIT, CaseIdBean.class);
			query.setParameter("bankerId", bankerId);
			listOfQueries = query.getResultList();
		} catch (NoResultException e) {
			throw new IBSException(ErrorMessages.NO_QUERIES);
		}
		return listOfQueries;
	}

	@Override
	public List<CaseIdBean> viewNewdebitQueries(Integer bankerId) throws IBSException {
		List<CaseIdBean> listOfQueries = null;
		try {
			TypedQuery<CaseIdBean> query = entityManager
					.createQuery(SqlQueries.SELECT_DATA_FROM_SERVICE_REQUEST_FOR_NEW_DEBIT, CaseIdBean.class);
			query.setParameter("bankerId", bankerId);
			listOfQueries = query.getResultList();
		} catch (NoResultException e) {
			throw new IBSException(ErrorMessages.NO_QUERIES);
		}
		return listOfQueries;
	}

	@Override
	public List<CaseIdBean> viewCustomerHistory(BigInteger uci) throws IBSException {
		List<CaseIdBean> listOfQueries = null;
		try {
			TypedQuery<CaseIdBean> query = entityManager.createQuery(SqlQueries.SELECT_CUSTOMER_HISTORY,
					CaseIdBean.class);
			query.setParameter("uci", uci);
			listOfQueries = query.getResultList();
		} catch (NoResultException e) {
			throw new IBSException(ErrorMessages.NO_QUERIES);
		}
		return listOfQueries;
	}

	@Override
	public BigInteger getApplicationId() throws IBSException {

		BigInteger applicationId = new BigInteger("0");

		try {
			TypedQuery<BigInteger> query = entityManager.createQuery(SqlQueries.SELECT_LAST_APPLICATION_ID,
					BigInteger.class);

			List<BigInteger> applicationId1 = query.getResultList();
			System.out.println(applicationId1);
			applicationId = Collections.max(applicationId1);
			System.out.println(applicationId);
		} catch (NoResultException e) {
			throw new IBSException(ErrorMessages.NO_QUERIES);
		}

		return applicationId;
	}

	@Override
	public void setMismatchQueryTimeStamp(String serviceRequest, LocalDateTime now) {

		CaseIdBean obj = entityManager.find(CaseIdBean.class, serviceRequest);
		obj.setBankTimeStamp(now);

	}

}
