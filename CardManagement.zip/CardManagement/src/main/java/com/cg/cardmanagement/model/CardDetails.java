package com.cg.cardmanagement.model;
public class CardDetails {

 

    private boolean value;
    private String message;
    private int flag;
    public boolean isValue() {
        return value;
    }
    public void setValue(boolean value) {
        this.value = value;
    }
    public int getFlag() {
		return flag;
	}
	public CardDetails() {
		super();
	}
	public void setFlag(int flag) {
		this.flag = flag;
	}
	public String getMessage() {
        return message;
    }
    public void setMessage(String message) {
        this.message = message;
    }
	public CardDetails(boolean value, String message, int flag) {
		super();
		this.value = value;
		this.message = message;
		this.flag = flag;
	}
	@Override
	public String toString() {
		return "CardDetails [value=" + value + ", message=" + message + ", flag=" + flag + "]";
	}
   
    
}