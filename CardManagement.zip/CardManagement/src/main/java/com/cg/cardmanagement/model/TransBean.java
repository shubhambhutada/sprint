package com.cg.cardmanagement.model;

import java.math.BigInteger;
import java.time.LocalDate;

public class TransBean {
	private BigInteger cardNumber;
	
    private LocalDate fromdate;
    private LocalDate enddate;
	public BigInteger getCardNumber() {
		return cardNumber;
	}
	public void setCardNumber(BigInteger cardNumber) {
		this.cardNumber = cardNumber;
	}
	public LocalDate getFromdate() {
		return fromdate;
	}
	public void setFromdate(LocalDate fromdate) {
		this.fromdate = fromdate;
	}
	public LocalDate getEnddate() {
		return enddate;
	}
	public void setEnddate(LocalDate enddate) {
		this.enddate = enddate;
	}
	@Override
	public String toString() {
		return "TransBean [cardNumber=" + cardNumber + ", fromdate=" + fromdate + ", enddate=" + enddate + "]";
	}
	public TransBean(BigInteger cardNumber, LocalDate fromdate, LocalDate enddate) {
		super();
		this.cardNumber = cardNumber;
		this.fromdate = fromdate;
		this.enddate = enddate;
	}
	public TransBean() {
		super();
	}
	
	
}
