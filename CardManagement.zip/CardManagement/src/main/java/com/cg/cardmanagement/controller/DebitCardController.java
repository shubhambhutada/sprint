package com.cg.cardmanagement.controller;

import java.math.BigInteger;
import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.cardmanagement.exception.IBSException;
import com.cg.cardmanagement.model.AccBean;
import com.cg.cardmanagement.model.CardDetails;
import com.cg.cardmanagement.model.CaseIdBean;
import com.cg.cardmanagement.model.DebitCardBean;
import com.cg.cardmanagement.model.TransBean;
import com.cg.cardmanagement.model.TransBean1;
import com.cg.cardmanagement.model.Transaction;
import com.cg.cardmanagement.service.DebitCustomer;
import com.cg.cardmanagement.service.DebitCustomerVerification;

@RestController
@Scope("session")
@RequestMapping("/debit")
@CrossOrigin
public class DebitCardController {

	@Autowired
	private DebitCustomer debitService;
	@Autowired
	private DebitCustomerVerification debitVerify;

//	
//	@GetMapping("/debitlist")
//    public ResponseEntity<List<DebitCardBean>> list() throws AdbException {
//        System.out.println("abhcbskdbfhb");
//        // List<DebitCardBean>debitCardBeans = debitService.viewAllDebitCards();
//        List<DebitCardBean> debitCardBeansSorted = contactService.viewAllSortedDebitCards();
//        System.out.println(debitCardBeansSorted.toString());
//        return new ResponseEntity<List<DebitCardBean>>(debitCardBeansSorted, HttpStatus.OK);
//    }
//    @GetMapping("/carddisplaymenu/{cardNumber}")
//    public ResponseEntity<DebitCardBean> cardDetails(@PathVariable("cardNumber") BigInteger cardNumber) throws IBSException {
//        DebitCardBean object = contactService.fetchDebitdetails(cardNumber);
//
// 
//
//        return new ResponseEntity<DebitCardBean>(object, HttpStatus.OK);
//    }
	
	@GetMapping("/debitlist")
    public ResponseEntity<List<DebitCardBean>> list() throws IBSException {
        System.out.println("abhcbskdbfhb");
        // List<DebitCardBean>debitCardBeans = debitService.viewAllDebitCards();
        List<DebitCardBean> debitCardBeansSorted = debitService.viewAllSortedDebitCards();
        System.out.println(debitCardBeansSorted.toString());
        return new ResponseEntity<List<DebitCardBean>>(debitCardBeansSorted, HttpStatus.OK);
    }
    @PostMapping("/carddisplaymenu")
    //checkQuery
    public ResponseEntity<DebitCardBean> cardDetails(@RequestBody DebitCardBean d) throws IBSException {
    	BigInteger cardNumber = d.getCardNumber();
        DebitCardBean object = debitService.fetchDebitdetails(cardNumber);

        return new ResponseEntity<DebitCardBean>(object, HttpStatus.OK);
    }

	@PatchMapping(value = "/block")
	public ResponseEntity<CardDetails> block(@RequestBody DebitCardBean d) throws IBSException {
		
		String pin = d.getCurrentPin();
		BigInteger cardNumber = d.getCardNumber();
		CardDetails output = new CardDetails();
		if (debitVerify.verifyDebitCardPin(pin)) {
	
			if (!debitService.getDebitcardStatus(cardNumber).equalsIgnoreCase("Blocked")) {
				System.out.println(debitVerify.verifyDebitPin(pin, cardNumber));
				if (debitVerify.verifyDebitPin(pin, cardNumber)) {
					
					debitService.requestDebitCardLost(cardNumber);
					output.setValue(true);
					output.setMessage(" Your card has been Blocked. Contact branch for further process!");
				} else {	output.setValue(false);
					output.setMessage("Incorrect Pin, Try again!");
				}
			} else {
				output.setValue(false);
				output.setMessage( "Card already blocked");
			}
		} else {	output.setValue(false);
			output.setMessage("Invalid pin format");

		}
		return new ResponseEntity<CardDetails>(output, HttpStatus.OK);

	}

	

	@PatchMapping(value = "/activate")
	public ResponseEntity<CardDetails> activate(@RequestBody DebitCardBean d) throws IBSException {
		String pin = d.getCurrentPin();
		BigInteger cardNumber = d.getCardNumber();

		CardDetails output = new CardDetails();
		if (debitVerify.verifyDebitCardPin(pin)) {
			if (debitService.getDebitcardStatus(cardNumber).equalsIgnoreCase("Inactive")) {
				if (debitVerify.verifyDebitPin(pin, cardNumber)) {
					debitService.activateDebitCard(cardNumber);
					output.setMessage("Card successfully activated!");
					output.setValue(true);
					
				} else {
					output.setMessage( "Incorrect Pin, Try again!");
					output.setValue(false);
				}
			} else {
				String status = debitService.getDebitcardStatus(cardNumber);
				output.setMessage("Card already " + status);
				output.setValue(false);
				
			}

		} else {
			output.setMessage("Invalid pin format");
			output.setValue(false);

		}
		return new ResponseEntity<CardDetails>(output, HttpStatus.OK);

	}

	@PatchMapping(value = "/deactivate")
	public ResponseEntity<CardDetails> deactivate(@RequestBody DebitCardBean d) throws IBSException {
	
		String pin = d.getCurrentPin();
		BigInteger cardNumber = d.getCardNumber();
		CardDetails output = new CardDetails();
System.out.println("enter");
System.out.println(debitService.getDebitcardStatus(cardNumber).equalsIgnoreCase("Active"));
		if (debitService.getDebitcardStatus(cardNumber).equalsIgnoreCase("Active")) {
			System.out.println(debitService.getDebitcardStatus(cardNumber).equalsIgnoreCase("Active"));
			if (debitVerify.verifyDebitCardPin(pin)) {
				if (debitVerify.verifyDebitPin(pin, cardNumber)) {
					debitService.deactivateDebitCard(cardNumber);
					output.setMessage("Card successfully deactivated!");
					output.setValue(true);
				} else {
			
					output.setMessage("Incorrect Pin, Try again!");
					output.setValue(false);
				}
			} else {
				
				output.setMessage("Invalid pin format");
				output.setValue(false);

			}
		} else {
			String status = debitService.getDebitcardStatus(cardNumber);
			output.setMessage("Card already " + status);
			output.setValue(false);

		}
		return new ResponseEntity<CardDetails>(output, HttpStatus.OK);

	}
	
	
	
	@PostMapping(value = "/reset") 
    public ResponseEntity<CardDetails>resetPin(@RequestBody DebitCardBean d) throws IBSException {
		CardDetails output = new CardDetails();
        String pin = d.getCurrentPin();
		BigInteger cardNumber = d.getCardNumber();
     

 

            if (debitVerify.verifyDebitPin(pin, cardNumber)) {
               
                output.setMessage("PIN VERIFIED");
                output.setValue(true);
            } else {
            	
            	output.setMessage( "PINS DO NOT MATCH!! TRY AGAIN");
				output.setValue(false);
            }
            return new ResponseEntity<CardDetails>(output, HttpStatus.OK);
        
    }
	
	
	
	
	@PatchMapping(value = "/resetpin")
	public ResponseEntity<CardDetails> resetPin2(@RequestBody DebitCardBean d) throws IBSException {
		CardDetails output = new CardDetails();
		BigInteger cardNumber = d.getCardNumber();
		String newpin = d.getCurrentPin();
       
           // if (newpin2.equals(newpin)) {
                debitService.resetDebitPin(cardNumber, newpin);
                output.setMessage("PIN SUCCESSFULLY CHANGED");
				output.setValue(true);
           
        	return new ResponseEntity<CardDetails>(output, HttpStatus.OK);
       
    }

	
	@PostMapping(value = "/check")
    public  ResponseEntity<CardDetails> check(@RequestBody CaseIdBean caseIdBean) throws IBSException  {
		CardDetails output = new CardDetails();
      
        BigInteger cardNumber = caseIdBean.getCardNumber();
        
            if (debitService.getDebitcardStatus(cardNumber).equalsIgnoreCase("Blocked")
                    || debitService.getDebitcardStatus(cardNumber).equalsIgnoreCase("Inactive")) {
            	
            	 output.setMessage( " You can not perform this function on "+debitService.getDebitcardStatus(cardNumber)+" card");
 				output.setValue(true);
            }
            else {
            	output.setValue(false);
            	
            	
            }
               return new ResponseEntity<CardDetails>(output, HttpStatus.OK);
            
	}
	
	@PostMapping(value = "/checkactive")
    public  ResponseEntity<CardDetails> checkActive(@RequestBody CaseIdBean caseIdBean) throws IBSException  {
		CardDetails output = new CardDetails();
      
        BigInteger cardNumber = caseIdBean.getCardNumber();
        
            if (debitService.getDebitcardStatus(cardNumber).equalsIgnoreCase("Blocked")
                    || debitService.getDebitcardStatus(cardNumber).equalsIgnoreCase("Active")) {
            	
            	 output.setMessage(" You can not perform this function on "+debitService.getDebitcardStatus(cardNumber)+" card");
 				output.setValue(true);
            }
               return new ResponseEntity<CardDetails>(output, HttpStatus.OK);
            
	}
               
	
	
	
	
	@PostMapping(value = "/upgrade")
    public  ResponseEntity<CardDetails> upgrade(@RequestBody CaseIdBean caseIdBean) throws IBSException  {
		CardDetails output = new CardDetails();
        String type = null;
        BigInteger cardNumber = caseIdBean.getCardNumber();
        
            if (!debitService.getDebitcardStatus(cardNumber).equalsIgnoreCase("Blocked")
                    && !debitService.getDebitcardStatus(cardNumber).equalsIgnoreCase("Inactive")) {
                type = debitService.getDebitcardType(cardNumber);
                if (type.equalsIgnoreCase("Silver")) {
                    output.setFlag(1);
                    output.setValue(true);
                } else if (type.equalsIgnoreCase("Gold")) {
                	 output.setFlag(2);
                     output.setValue(true);
                } else {
                	 output.setFlag(3);
                     output.setValue(true);
                }
            } else {
                
                output.setMessage( " You can not upgrade a blocked/inactive card");
				output.setValue(false);
            }
           

 
				return new ResponseEntity<CardDetails>(output, HttpStatus.OK);

    }
	
            
            @PostMapping(value = "/upgrade2")
            public  ResponseEntity<CardDetails> upgrade2(@RequestBody AccBean a) throws IBSException {
            	CardDetails output = new CardDetails();
              
                BigInteger cardNumber = a.getCardNumber();
                String type=a.getType();
                String remarks="";
                System.out.println();
                    String num = debitService.requestDebitCardUpgrade(cardNumber, type, remarks);

                    output.setMessage(" Your reference Id is" + num);
    				output.setValue(true);
                    
    				return new ResponseEntity<CardDetails>(output, HttpStatus.OK);

            }

	

            @PostMapping(value = "/requestStatement")
	public ResponseEntity<List<Transaction>> requestStatement(@RequestBody TransBean t) throws IBSException {
		BigInteger cardNumber = t.getCardNumber();
//		String fromdate=t.getFromdate();
//		String enddate=t.getEnddate();
//		System.out.println(enddate);
//		DateTimeFormatter formatter = DateTimeFormatter.ISO_DATE;
//	
//		LocalDate startDate1 = LocalDate.parse(fromdate, formatter);
//		LocalDate endDate1 = LocalDate.parse(enddate, formatter);
		LocalDate startDate1=t.getFromdate();
		LocalDate endDate1=t.getEnddate();
		List<Transaction> bean1 = debitService.getDebitTransactions(startDate1, endDate1, cardNumber);
		return new ResponseEntity<List<Transaction>>(bean1, HttpStatus.OK);

	}
            @PostMapping(value = "/getAllTransactions")
        	public ResponseEntity<List<Transaction>> getAllTransactions(@RequestBody TransBean t) throws IBSException {
        		BigInteger cardNumber = t.getCardNumber();
        	

        	System.out.println("aaaaaaaaaa");
        	
        		List<Transaction> bean1 = debitService.getDebitAllTransactions(cardNumber);
        		System.out.println(bean1);
        		return new ResponseEntity<List<Transaction>>(bean1, HttpStatus.OK);

        	}
	@PostMapping(value = "/mismatchDebit")
	public ResponseEntity<CardDetails> debitMismatch(@RequestBody TransBean1 t1) throws IBSException {
		Integer transaction=t1.getTransactionId();
		String remarks=t1.getRemarks();
		 
		  Integer transactionId = Integer.valueOf(transaction);
		
		CardDetails output = new CardDetails();
		String refId = debitService.raiseDebitMismatchTicket(transactionId, remarks);
		output.setMessage( "  your reference ID is " + refId);
		output.setValue(true);
		return new ResponseEntity<CardDetails>(output, HttpStatus.OK);

	}

	@PostMapping(value = "/applynewdebit")
	public ResponseEntity<CardDetails> applyNewDebitCard2(@RequestBody AccBean a) throws IBSException {
		BigInteger accountNumber=new BigInteger("12345678910");
		String type=a.getType();
	
		CardDetails output = new CardDetails();
		if (debitService.checkDebitCardCount()) {
			System.out.println("a");
			String num = debitService.applyNewDebitCard(accountNumber, type);
			
			output.setMessage(" Your reference Id is" + num);
			output.setValue(true);
		} else {
			
			output.setMessage( "You already have 3  debit cards.");
			output.setValue(false);

		}
		return new ResponseEntity<CardDetails>(output, HttpStatus.OK);

	}

	@ExceptionHandler
	public ResponseEntity<String> ibsException(IBSException e) {

		String output = e.getMessage();
		return new ResponseEntity<String>(output, HttpStatus.OK);
	}
}
