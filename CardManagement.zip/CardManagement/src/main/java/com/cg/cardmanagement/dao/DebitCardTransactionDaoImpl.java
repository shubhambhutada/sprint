package com.cg.cardmanagement.dao;

import java.math.BigInteger;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.cardmanagement.exception.ErrorMessages;
import com.cg.cardmanagement.exception.IBSException;
import com.cg.cardmanagement.model.Transaction;

@Repository
public class DebitCardTransactionDaoImpl implements DebitCardTransactionDao {
	//private static Logger logger = Logger.getLogger(DebitCardTransactionDaoImpl.class);
	@PersistenceContext
	private EntityManager entityManager;

	

	@Override
	public boolean verifyDebitTransactionId(Integer transactionId) throws IBSException {
		//logger.info("entered into verifyDebTransactionId method of DebitCardTransactionDaoImpl class");
		boolean result = false;

		Transaction d = entityManager.find(Transaction.class, transactionId);

		if (d != null) {
			result = true;
		}

		return result;

	}

	@Override
	public List<Transaction> getDebitTrans(LocalDate startDate , LocalDate endDate, BigInteger debitCardNumber) throws IBSException {
		//logger.info("entered into getDebitTrans method of DebitCardTransactionDaoImpl class");
		
        LocalDateTime startDate1 = startDate.atTime(LocalTime.now());
        LocalDateTime endDate1 = endDate.atTime(LocalTime.now());
        List<Transaction> debitCards = null;
        try {
            TypedQuery<Transaction> query = entityManager.createQuery(
                    "Select d from Transaction d JOIN d.debitBeanObject c WHERE d.transactionDate BETWEEN :start and :end AND c.cardNumber=:cardNum ",
                    Transaction.class);
            query.setParameter("start", startDate1);
            query.setParameter("end", endDate1);
            query.setParameter("cardNum", debitCardNumber);
            debitCards = query.getResultList();
        } catch (NoResultException e) {
            throw new IBSException(ErrorMessages.NO_TRANSACTIONS_MESSAGE);
        }
        return debitCards;
  
  
	}

	@Override
	public BigInteger getDMUci(Integer transactionID) throws IBSException {
		//logger.info("entered into getDMUci method of DebitCardTransactionDaoImpl class");
		BigInteger accNo = null;
		BigInteger uci = null;
		try {
			TypedQuery<BigInteger> query = entityManager.createQuery(
					"Select d.accountNumber from Transaction d where d.transactionId=:transactionId", BigInteger.class);
			query.setParameter("transactionId", transactionID);
			accNo = query.getSingleResult();
			
		 uci=getUci(accNo);
		} catch (NoResultException e) {
			throw new IBSException(ErrorMessages.NO_UCI);
		}
		return uci;

	}

	
	
	
	
	private BigInteger getUci(BigInteger accNo) throws IBSException {
		BigInteger uci = null;
		try {
		TypedQuery<BigInteger> query1 = entityManager.createQuery(
				"Select a.UCI from AccountBean c join c.customerBeanObject a  where c.accountNumber= :accNo ", BigInteger.class);
				query1.setParameter("accNo", accNo);
				uci = query1.getSingleResult();
		} catch (NoResultException e) {
			throw new IBSException(ErrorMessages.NO_UCI);
		}
		return uci;	
		
		
		
		
		
	}
	@Override
	public BigInteger getDebitCardNumber(Integer transactionID) throws IBSException {
		//logger.info("entered into getDebitCardNumber method of DebitCardTransactionDaoImpl class");
		BigInteger cardNumber = null;
		try {
			TypedQuery<BigInteger> query = entityManager.createQuery(
					"Select c.cardNumber from Transaction d  join d.debitBeanObject c where d.transactionId=:transactionId",
					BigInteger.class);
			query.setParameter("transactionId", transactionID);

			cardNumber = query.getSingleResult();
		} catch (NoResultException e) {
			throw new IBSException(ErrorMessages.DEB_CARD_NOT_EXIST_MESSAGE);
		}
		return cardNumber;

	}

	@Override
	public Integer getDebitMismatchTranscId(String queryId) throws IBSException {
		
		Integer transcId = null;
		try {
			TypedQuery<String> query = entityManager.createQuery(
					"Select d.defineServiceRequest from CaseIdBean d  WHERE d.caseIdTotal =:QueryId ", String.class);
			query.setParameter("QueryId", queryId);

			transcId = new Integer(query.getSingleResult());
		} catch (NoResultException e) {
			throw new IBSException(ErrorMessages.TRANS_NOT_EXIST_MESSAGE);
		}
		return transcId;

	}

	@Override
	public Transaction getDebitMismatchTransc(Integer mismatchTransactionId) throws IBSException {

	Transaction debitCardList;
		try {
		/*	TypedQuery<DebitCardTransaction> query = entityManager.createQuery(
					"Select d from DebitCardTransaction d WHERE d.transactionId =:TransactionId ",
					DebitCardTransaction.class);*/
		
			debitCardList =entityManager.find(Transaction.class, mismatchTransactionId);

		} catch (NullPointerException e) {

			throw new IBSException(ErrorMessages.TRANSACTION_ID_NOT_EXIST_MESSAGE);
		}
		return debitCardList;
	}

	@Override
	public boolean checkTransactions(BigInteger debitCardNumber) throws IBSException {
		boolean result = false;
		
		try {
            TypedQuery<Transaction> query = entityManager.createQuery(
                    "Select d from DebitCardTransaction d JOIN d.debitBeanObject c WHERE c.cardNumber=:cardNum ",
                    Transaction.class);
    
            query.setParameter("cardNum", debitCardNumber);
           List<Transaction> debitCards = query.getResultList();
           if (debitCards.size()>0) {
        	   result = true;
           }
        } catch (NoResultException e) {
            throw new IBSException(ErrorMessages.NO_TRANSACTIONS_MESSAGE);
        }
		
		
		
        return result;
  
	}

}
