package com.cg.cardmanagement.model;

import java.math.BigInteger;

public class TransBean1 {
	private Integer transactionId;
	private String remarks;
	public Integer getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(Integer transactionId) {
		this.transactionId = transactionId;
	}
	public TransBean1() {
		super();
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	@Override
	public String toString() {
		return "TransBean1 [transactionId=" + transactionId + ", remarks=" + remarks + "]";
	}
	public TransBean1(Integer transactionId, String remarks) {
		super();
		this.transactionId = transactionId;
		this.remarks = remarks;
	}

}
