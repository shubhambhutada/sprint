import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import {BankerServiceService} from '../service/banker-service.service';
import { CaseidBean } from '../model/caseidbean';
import Swal from 'sweetalert2';
import { Trans } from '../model/trans';
@Component({
  selector: 'app-list-credit-mismatch-requests',
  templateUrl: './list-credit-mismatch-requests.component.html',
  styleUrls: ['./list-credit-mismatch-requests.component.css']
})
export class ListCreditMismatchRequestsComponent implements OnInit {

  bean1:Trans;
  bean: CaseidBean[];
  constructor(private route:Router ,private bankerService:BankerServiceService ) { }

  ngOnInit() {
    this.load()
  }
  load() {
    console.log("enter1");
    const bankerid1=localStorage.getItem("bankerid");
    var bankerId = Number(bankerid1)
    console.log(bankerId)
    let banker={
      bankerId
    }

    
    this.bankerService.CreditMismatchQuery(banker).subscribe(
    
      (data) => {
        console.log("enter"); 
        console.log(data)
      console.log("dscdxczx");

  
        this.bean = data;
       
       
     
    }
      );
}

    viewTransaction(caseIdTotal:string){
      //const caseId1=localStorage.getItem("caseIdTotal");
      //var caseIdTotal=String(caseId1);
      console.log(caseIdTotal);
      let CaseIdObj={
        caseIdTotal
      
      }
      this.bankerService.showCreditTransaction(CaseIdObj).subscribe(
        (data) => {
          console.log("entergfdvbdf"); 
          console.log(data)
        
      
      
          this.bean1 = data;
         
         
       
      }
      
      
      
      )
      
      
      
          
        }
      
      
        blockTrans(cardNumber:number){
      console.log(cardNumber)
          Swal.fire({
            title: 'Are you sure ?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, Block it'
          }).then((result) => {
            if (result.value) {
              let cardDetails ={
                cardNumber
              }
              this.bankerService.blockCreditCard(cardDetails).subscribe(
                data => {
                  console.log(data);console.log(data.value);
                         if(data.value) {
                          console.log(data.value);
                          Swal.fire({
                            title: 'All done!',
                            html: `
                              Your card has been blocked!
                            `,
                            confirmButtonText: 'DONE!'
                          })
                         } else {
                          console.log(data.value);
                         Swal.fire({
                          icon: 'error',
                          title: 'Oops...',
                          text: (data.message),
                          footer: '<a href>Why do I have this issue?</a>'
                         })
                      }
                        
                       })
              
            }
          })
      
      
        }
}
