import { Component, OnInit } from '@angular/core';
import {BankerServiceService} from '../service/banker-service.service';
import { CaseidBean } from '../model/caseidbean';
import {Router} from '@angular/router';

@Component({
  selector: 'app-view-requests',
  templateUrl: './view-requests.component.html',
  styleUrls: ['./view-requests.component.css']
})
export class ViewRequestsComponent implements OnInit {
  bean: CaseidBean[];
  constructor(private route:Router ,private bankerService:BankerServiceService) { }

  ngOnInit() {
    this.viewAllRequests()
  }
viewAllRequests(){
    console.log("fdd")
   
  
   console.log("dfcs")
   this.bankerService.viewRequests().subscribe(

    data=>{
console.log(data);
    this.bean= data;
   }

   )
    
   
  }
}
