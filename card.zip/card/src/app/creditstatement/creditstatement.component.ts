import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Trans } from '../model/trans';
import Swal from 'sweetalert2';
import { CreditserviceService } from '../service/creditservice.service';
@Component({
  selector: 'app-credit-statement',
  templateUrl: './creditstatement.component.html',
  styleUrls: ['./creditstatement.Component.css']
})
export class CreditstatementComponent implements OnInit {
  dobStr: string;
  dobStr1: string;
    bean:Trans;
    bean1: Trans[];
    constructor(private router:Router, private creditService:CreditserviceService) {
    }
  
  
  ngOnInit() {
this.getTransaction();
  }
  getTransaction(){
 
    const cardNumber1 = localStorage.getItem("card");
    var cardNumber = Number(cardNumber1)
    let cardDetails = {
      cardNumber
    
    }
   console.log(cardNumber);
   this.creditService.getAllTransactions(cardDetails).subscribe(

    data=>{
console.log(data);
    this.bean1 = data;
   }

   )
    
   
  }

  getTransactions(){
    const cardNumber1 = localStorage.getItem("card");
    var cardNumber = Number(cardNumber1);
    var fromdate= new Date(this.dobStr);
    var enddate=new Date(this.dobStr1);
console.log("cxd");

    if(fromdate>enddate)
{console.log("cds");
  Swal.fire({
    icon: 'warning',
    title:'Wrong ',
    text:' Enter dates in right chronological order',
showCancelButton:false

  })
}else{
let  cardDetails={
  cardNumber,
  fromdate,
  enddate

}
this.creditService.getTransactions(cardDetails).subscribe(
  data=>{
    console.log(data);
        this.bean1 = data;
       }
    
  
  
  )}

  }

  reportTransaction(transactionId:number){
    const cardNumber1 = localStorage.getItem("card");
    var cardNumber = Number(cardNumber1);
    var transactionId=transactionId;
    Swal.mixin({
      input: 'text',
      confirmButtonText: 'Submit',
      showCancelButton: true
    }).queue([
      {
        icon: 'warning',
        title: ' Enter any remarks',
        text: 'ex. Fraudulant'
      }
    ]).then((result) => {
      if (result.value) {
        const remarks = result.value[0];
        let cardDetails = {
          cardNumber,
          transactionId,
          remarks
        }
        console.log(cardDetails)
    this.creditService.report(cardDetails).subscribe(
  data=>{
    console.log(data);
  if(data.value) {
      console.log(data.value);

      Swal.fire({
        icon:'success',
        title: 'Ticket raised successfully',
       text: data.message,
        confirmButtonText: 'DONE!'
      })}
        
       }
)
    }
})
}

}