import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewCustomerHistoryComponent } from './view-customer-history.component';

describe('ViewCustomerHistoryComponent', () => {
  let component: ViewCustomerHistoryComponent;
  let fixture: ComponentFixture<ViewCustomerHistoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewCustomerHistoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewCustomerHistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
