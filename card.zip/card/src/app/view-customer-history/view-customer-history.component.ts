import { Component, OnInit } from '@angular/core';
import {BankerServiceService} from '../service/banker-service.service';
import { CaseidBean } from '../model/caseidbean';
import {Router} from '@angular/router';
@Component({
  selector: 'app-view-customer-history',
  templateUrl: './view-customer-history.component.html',
  styleUrls: ['./view-customer-history.component.css']
})
export class ViewCustomerHistoryComponent implements OnInit {
  bean: CaseidBean[];
  constructor(private route:Router ,private bankerService:BankerServiceService) { }

  ngOnInit() {
    this.viewCustomerHistory()

  }
  viewCustomerHistory(){
    console.log("fdd")
   
  
   console.log("dfcs")
   this.bankerService.viewCustomerHistory().subscribe(

    data=>{
console.log(data);
    this.bean= data;
   }

   )
    
   
  }

}
