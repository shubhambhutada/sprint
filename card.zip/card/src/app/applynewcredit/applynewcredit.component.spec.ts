import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ApplynewcreditComponent } from './applynewcredit.component';

describe('ApplynewcreditComponent', () => {
  let component: ApplynewcreditComponent;
  let fixture: ComponentFixture<ApplynewcreditComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ApplynewcreditComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ApplynewcreditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
