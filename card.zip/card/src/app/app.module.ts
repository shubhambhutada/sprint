import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';

import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { GroupsComponent } from './groups/groups.component';
import { ContactsListComponent } from './contacts-list/contacts-list.component';
import { ContactFormComponent } from './contact-form/contact-form.component';
import { SearchContactComponent } from './search-contact/search-contact.component';
import { CustomerComponent } from './customer/customer.component';
import { BankComponent } from './bank/bank.component';

import { ManagedebitComponent } from './managedebit/managedebit.component';
import { ManagecreditComponent } from './managecredit/managecredit.component';
import { ShowCardComponent } from './show-card/show-card.component';
import { UpgradeComponent } from './upgrade/upgrade.component';
import { DebitStatementComponent } from './debit-statement/debit-statement.component';
import { DebitlistComponent } from './debitlist/debitlist.component';
import { ApplynewdebitComponent } from './applynewdebit/applynewdebit.component';
import { ShowcreditcardComponent } from './showcreditcard/showcreditcard.component';
import { CreditlistComponent } from './creditlist/creditlist.component';
import { UpgradecreditcardComponent } from './upgradecreditcard/upgradecreditcard.component';
import { CreditstatementComponent } from './creditstatement/creditstatement.component';
import { ApplynewcreditComponent } from './applynewcredit/applynewcredit.component';
import { ViewRequestsComponent } from './view-requests/view-requests.component';
import { ViewCustomerHistoryComponent } from './view-customer-history/view-customer-history.component';
import { ListQueryComponent } from './list-query/list-query.component';
import { ListCreditQueryComponent } from './list-credit-query/list-credit-query.component';
import { ListMismatchRequestsComponent } from './list-mismatch-requests/list-mismatch-requests.component';
import { ListCreditMismatchRequestsComponent } from './list-credit-mismatch-requests/list-credit-mismatch-requests.component';
import { ListUpgradeRequestsComponent } from './list-upgrade-requests/list-upgrade-requests.component';
import { ListCreditUpgradeRequestsComponent } from './list-credit-upgrade-requests/list-credit-upgrade-requests.component';
import { AboutusComponent } from './aboutus/aboutus.component';
import { WhyissueComponent } from './whyissue/whyissue.component';

@NgModule({
  declarations: [
    AppComponent,
    DashboardComponent,
    GroupsComponent,
    ContactsListComponent,
    ContactFormComponent,
    SearchContactComponent,
    CustomerComponent,
    BankComponent,

    ManagedebitComponent,
    ManagecreditComponent,
    ShowCardComponent,
    UpgradeComponent,
    DebitStatementComponent,
    DebitlistComponent,
    ApplynewdebitComponent,
    ShowcreditcardComponent,
    CreditlistComponent,
    UpgradecreditcardComponent,
    CreditstatementComponent,
    ApplynewcreditComponent,
    ViewRequestsComponent,
    ViewCustomerHistoryComponent,
    ListQueryComponent,
    ListCreditQueryComponent,
    ListMismatchRequestsComponent,
    ListCreditMismatchRequestsComponent,
    ListUpgradeRequestsComponent,
    ListCreditUpgradeRequestsComponent,
    AboutusComponent,
    WhyissueComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
