
import { Debitmodel } from '../model/debitmodel';
//import {  CreditserviceService} from '../service/creditservice.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';
import { CreditserviceService } from '../service/creditservice.service';

@Component({
  selector: 'app-creditlist',
  templateUrl: './creditlist.component.html',
  styleUrls: ['./creditlist.component.css']
})
export class CreditlistComponent {

  bean: Debitmodel[];
 
  constructor(private creditService: CreditserviceService, private router:Router) {
  }

  ngOnInit(){
    this.load() ;
  }

  load() {
    console.log("enter1");
    this.creditService.getAll().subscribe(
    
      (data) => {
        console.log("enter"); 
        console.log(data)
       
        this.bean = data;
     
    }
      );
}

details(cardNumber: number){
  console.log(cardNumber)

localStorage.setItem("creditCardNumber",cardNumber.toString());
  this.router.navigateByUrl("getcreditDetails");
  
}






}
