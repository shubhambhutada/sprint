import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment.prod';
import { Contact } from '../model/contact';
import { Observable } from 'rxjs';
import { GroupStatistics } from '../model/group-statistics';

@Injectable({
  providedIn: 'root'
})
export class ContactService {
  
  baseUrl: string;

  constructor(private http: HttpClient) {
    this.baseUrl = `${environment.baseMwUrl}/contact`;
  }

  getAll(): Observable<Contact[]> {
    return this.http.get<Contact[]>(this.baseUrl);
  }

  getById(id: number): Observable<Contact> {
    return this.http.get<Contact>(`${this.baseUrl}/${id}`);
  }

  add(contact: Contact): Observable<Contact> {
    return this.http.post<Contact>(this.baseUrl, contact);
  }

  update(contact: Contact): Observable<Contact> {
    return this.http.put<Contact>(this.baseUrl, contact);
  }

  deleteById(id: number): Observable<any> {
    return this.http.delete<any>(`${this.baseUrl}/${id}`);
  }
}
