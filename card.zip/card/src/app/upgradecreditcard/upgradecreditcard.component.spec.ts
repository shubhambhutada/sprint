import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpgradecreditcardComponent } from './upgradecreditcard.component';

describe('UpgradecreditcardComponent', () => {
  let component: UpgradecreditcardComponent;
  let fixture: ComponentFixture<UpgradecreditcardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpgradecreditcardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpgradecreditcardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
