import { Caseidbean } from './caseidbean';

describe('Caseidbean', () => {
  it('should create an instance', () => {
    expect(new Caseidbean()).toBeTruthy();
  });
});
