export class Creditmodel {
    
        public cardNumber:number;
        public cardStatus:String;
        public nameOnCard:String;
        public cvvNum:String;
        public currentPin:String;
        public cardType:String;
        public dateOfExpiry:Date;
        
        
}
