
import { Debitmodel } from '../model/debitmodel';
import { DebitserviceService } from '../service/debitservice.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-debitlist',
  templateUrl: './debitlist.component.html',
  styleUrls: ['./debitlist.component.css']
})
export class DebitlistComponent {

  bean: Debitmodel[];
 
  constructor(private debitService: DebitserviceService, private router:Router) {
  }

  ngOnInit(){
    this.load() ;
  }

  load() {
    console.log("enter1");
    this.debitService.getAll().subscribe(
    
      (data) => {
        console.log("enter"); 
        console.log(data)
       
        this.bean = data;
     
    }
      );
}

details(cardNumber: number){
  console.log(cardNumber)

localStorage.setItem("cardNumber",cardNumber.toString());
  this.router.navigateByUrl("getDetails");
  
}






}
