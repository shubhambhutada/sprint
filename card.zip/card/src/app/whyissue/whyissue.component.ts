import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-whyissue',
  templateUrl: './whyissue.component.html',
  styleUrls: ['./whyissue.component.css']
})
export class WhyissueComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
