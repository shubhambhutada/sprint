import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WhyissueComponent } from './whyissue.component';

describe('WhyissueComponent', () => {
  let component: WhyissueComponent;
  let fixture: ComponentFixture<WhyissueComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WhyissueComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WhyissueComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
