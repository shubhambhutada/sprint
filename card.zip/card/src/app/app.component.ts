import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'address-book-app';
  constructor(private router : Router) { }

  ngOnInit() {
  }
  transfer1(){
    localStorage.setItem("bankerid","2")
    const abc = localStorage.getItem("bankerid")
    console.log(abc)
    this.router.navigateByUrl("/bank")
   }
   transfer2(){
    localStorage.setItem("bankerid","2")
    const abc = localStorage.getItem("bankerid")
    console.log(abc)
    this.router.navigateByUrl("/bank")
   }
   transfer3(){
    localStorage.setItem("bankerid","3")
    const abc = localStorage.getItem("bankerid")
    console.log(abc)
    this.router.navigateByUrl("/bank")
   }
   transfer4(){
    localStorage.setItem("bankerid","4")
    const abc = localStorage.getItem("bankerid")
    console.log(abc)
    this.router.navigateByUrl("/bank")
   }
   transfer5(){
    localStorage.setItem("bankerid","5")
    const abc = localStorage.getItem("bankerid")
    console.log(abc)
    this.router.navigateByUrl("/bank")
   }
  
}
