import { Component, OnInit } from '@angular/core';

import { Router } from '@angular/router';

import { Trans } from '../model/trans';
import { DebitserviceService } from '../service/debitservice.service';

import Swal from 'sweetalert2';
@Component({
  selector: 'app-debit-statement',
  templateUrl: './debit-statement.component.html',
  styleUrls: ['./debit-statement.component.css']
})
export class DebitStatementComponent implements OnInit {
  dobStr: string;
  dobStr1: string;
    bean:Trans;
    bean1: Trans[];
    constructor(private debitService: DebitserviceService, private router:Router) {
    }
  
  
  ngOnInit() {
this.getTransaction();
  }
  getTransaction(){
 
    const cardNumber1 = localStorage.getItem("card");
    var cardNumber = Number(cardNumber1)
    let cardDetails = {
      cardNumber
    
    }
   console.log(cardNumber);
   this.debitService.getAllTransactions(cardDetails).subscribe(

    data=>{
console.log(data);
    this.bean1 = data;
   }

   )
    
   
  }

  getTransactions(){
    const cardNumber1 = localStorage.getItem("card");
    var cardNumber = Number(cardNumber1);
    var fromdate= new Date(this.dobStr);
    var enddate=new Date(this.dobStr1);
    console.log("djfbsdjkbfhsdbfhbhsdb")
    if(fromdate>enddate)
    {console.log("cds");
      Swal.fire({
        icon: 'warning',
        title:'Wrong ',
        text:' Enter dates in right chronological order',
        showCancelButton:false
   
    
      })
let  cardDetails={
  cardNumber,
  fromdate,
  enddate

}
this.debitService.getTransactions(cardDetails).subscribe(
  data=>{
    console.log(data);
        this.bean1 = data;
       }
    
  
  
  )}

  }

  reportTransaction(transactionId:number){


    console.log("debuit");
    const cardNumber1 = localStorage.getItem("card");
    var cardNumber = Number(cardNumber1);
    var transactionId=transactionId;
    Swal.mixin({
      input: 'text',
      confirmButtonText: 'Submit',
      showCancelButton: true
    }).queue([
      {
        title: ' Enter any remarks',
        text: 'ex. Fraudulant'
      }
    ]).then((result) => {
      if (result.value) {
        const remarks = result.value[0];
        let cardDetails = {
          cardNumber,
          transactionId,
          remarks
        }
    this.debitService.report(cardDetails).subscribe(
  data=>{
    console.log(data);
  if(data.value) {
      console.log(data.value);

      Swal.fire({
        title: 'Ticket raised successfully',
       text: data.message,
        confirmButtonText: 'DONE!'
      })}
        
       }
)
    }
})
}

}