import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import {DashboardComponent} from './dashboard/dashboard.component';
import {GroupsComponent} from './groups/groups.component';
import {ContactFormComponent} from './contact-form/contact-form.component';
import {SearchContactComponent} from './search-contact/search-contact.component';
import {ContactsListComponent} from './contacts-list/contacts-list.component';
import {CustomerComponent} from './customer/customer.component'
import {BankComponent } from './bank/bank.component';
import { ManagecreditComponent } from './managecredit/managecredit.component';
import {DebitlistComponent} from './debitlist/debitlist.component';
import{UpgradeComponent} from './upgrade/upgrade.component';
import{ShowCardComponent} from './show-card/show-card.component';
import {DebitStatementComponent} from './debit-statement/debit-statement.component';
import { ApplynewdebitComponent } from './applynewdebit/applynewdebit.component';
import { CreditstatementComponent } from './creditstatement/creditstatement.component';
import { ShowcreditcardComponent } from './showcreditcard/showcreditcard.component';
import { UpgradecreditcardComponent } from './upgradecreditcard/upgradecreditcard.component';
import { CreditlistComponent } from './creditlist/creditlist.component';
import { ApplynewcreditComponent } from './applynewcredit/applynewcredit.component';
import { ViewRequestsComponent } from './view-requests/view-requests.component';
import { ViewCustomerHistoryComponent } from './view-customer-history/view-customer-history.component';
import { ListCreditQueryComponent } from './list-credit-query/list-credit-query.component';
import { ListUpgradeRequestsComponent } from './list-upgrade-requests/list-upgrade-requests.component';
import { ListMismatchRequestsComponent } from './list-mismatch-requests/list-mismatch-requests.component';
import { ListCreditMismatchRequestsComponent } from './list-credit-mismatch-requests/list-credit-mismatch-requests.component';
import { ListCreditUpgradeRequestsComponent } from './list-credit-upgrade-requests/list-credit-upgrade-requests.component';
import { ListQueryComponent } from './list-query/list-query.component';
import { AppComponent } from './app.component';
import { AboutusComponent } from './aboutus/aboutus.component';
import { WhyissueComponent } from './whyissue/whyissue.component';


const routes: Routes = [
  {path:'',component:DashboardComponent,pathMatch:'full'},
  {path:'groups',component:GroupsComponent},
  {path:'contacts',component:ContactsListComponent},
  {path:'newContact',component:ContactFormComponent},
  {path:'editContact/:contactId',component:ContactFormComponent},

  {path:'search',component:SearchContactComponent},
  {path:'customer',component:CustomerComponent},
  {path:'bank',component:BankComponent},
  //{path:'manageexistingdebit',component:ManagedebitComponent},
  {path:'manageexisitngcredit',component:ManagecreditComponent},

  {path:'debitlist',component:DebitlistComponent},
  {path: 'upgrade1', component:UpgradeComponent},
  {path: 'getDetails', component:ShowCardComponent},
  {path:'showStatement',component:DebitStatementComponent},
  {path:'applynewdebit',component:ApplynewdebitComponent},
  {path: 'creditupgrade', component:UpgradecreditcardComponent},
  {path: 'getcreditDetails', component:ShowcreditcardComponent},
  {path:'showcreditStatement',component:CreditstatementComponent},
  {path:'creditlist',component:CreditlistComponent},
  {path:'applynewcredit',component:ApplynewcreditComponent},
  {path:'queryStatus',component:ViewRequestsComponent},
  {path:'viewCustomerHistory',component:ViewCustomerHistoryComponent},
  {path:'viewQueries',component:ListQueryComponent},
  {path:'viewCreditQueries',component:ListCreditQueryComponent},
{path:'viewUpgradeDebitQueries',component:ListUpgradeRequestsComponent},
{path:'viewUpgradeCreditQueries',component:ListCreditUpgradeRequestsComponent},
{path:'viewDebitMismatchQueries',component:ListMismatchRequestsComponent},
{path:'viewCreditMismatchQueries',component:ListCreditMismatchRequestsComponent},
{path:'aboutus',component:AboutusComponent},
{path:'whyissue',component:WhyissueComponent}


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
