import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManagedebitComponent } from './managedebit.component';

describe('ManagedebitComponent', () => {
  let component: ManagedebitComponent;
  let fixture: ComponentFixture<ManagedebitComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManagedebitComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManagedebitComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
