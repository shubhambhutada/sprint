import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowcreditcardComponent } from './showcreditcard.component';

describe('ShowcreditcardComponent', () => {
  let component: ShowcreditcardComponent;
  let fixture: ComponentFixture<ShowcreditcardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ShowcreditcardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ShowcreditcardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
