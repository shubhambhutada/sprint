import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent implements OnInit {

  constructor(private router:Router) {}

  ngOnInit() {
  }
transfer(){
 this.router.navigateByUrl("/debitlist")
}
transfer2(){
  this.router.navigateByUrl("/applynewdebit")
 }
 transfer3(){
  this.router.navigateByUrl("/applynewcredit")
 }
 transfer4(){
  this.router.navigateByUrl("/creditlist")
 }
 transfer5(){
  this.router.navigateByUrl("/queryStatus")
 }
}
