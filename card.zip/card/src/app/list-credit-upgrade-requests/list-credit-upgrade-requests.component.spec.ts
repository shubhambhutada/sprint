import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListCreditUpgradeRequestsComponent } from './list-credit-upgrade-requests.component';

describe('ListCreditUpgradeRequestsComponent', () => {
  let component: ListCreditUpgradeRequestsComponent;
  let fixture: ComponentFixture<ListCreditUpgradeRequestsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListCreditUpgradeRequestsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListCreditUpgradeRequestsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
