import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-bank',
  templateUrl: './bank.component.html',
  styleUrls: ['./bank.component.css']
})
export class BankComponent implements OnInit {

  constructor(private router : Router) { }

  ngOnInit() {
  }
  transfer1(){
    this.router.navigateByUrl("/viewCustomerHistory")
   }
   transfer4(){
    this.router.navigateByUrl("/viewQueries")
   }
   transfer5(){
    this.router.navigateByUrl("/viewCreditQueries")
   }
   transfer6(){
    this.router.navigateByUrl("/viewUpgradeDebitQueries")
   }

   transfer7(){
    this.router.navigateByUrl("/viewUpgradeCreditQueries")
   }  
   transfer8(){
    this.router.navigateByUrl("/viewDebitMismatchQueries")
   }  
   transfer9(){
    this.router.navigateByUrl("/viewCreditMismatchQueries")
   }  

   
   

   

}
